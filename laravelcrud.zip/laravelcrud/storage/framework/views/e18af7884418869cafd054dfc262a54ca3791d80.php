<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
	<div class="row">
		<legend>Laravel CRUD Application</legend>
		<div class="row">
			<div class="col-md-6 col-lg-6">
				<?php if(session('info')): ?>
				<div class="col-md-6 alert alert-success">
					<?php echo e(session('info')); ?>

				</div>
				<?php endif; ?>
			</div><!-- /.col-md6 -->
		</div><!-- /.row -->
		<table class="table table-striped table-hover ">
			<thead>
				<tr>
					<th>ID</th>
					<th>Title</th>
					<th>Description</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php if(count($articles) > 0): ?>
				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($article->id); ?></td>
					<td><?php echo e($article->title); ?></td>
					<td><?php echo e($article->description); ?></td>
					<td>
						<a href='<?php echo e(url("/read/{$article->id}")); ?>' class="label label-primary">Read</a> |
						<a href='<?php echo e(url("/update/{$article->id}")); ?>' class="label label-success">Update</a> |
						<a href='<?php echo e(url("/delete/{$article->id}")); ?>' class="label label-danger">Delete</a> |
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</tbody>
		</table> 
	</div><!-- /.row -->
</div><!-- /.container -->
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /* C:\xampp\htdocs\laravelcrud\resources\views/home.blade.php */ ?>