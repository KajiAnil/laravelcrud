
<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<form class="form-horizontal" method="POST" action="<?php echo e(url('/insert')); ?>">
				<?php echo e(csrf_field()); ?>

				<fieldset>
					<legend>Laravel CRUD Application</legend>
					<?php if(count($errors) > 0): ?>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="alert alert-danger">
								<?php echo e($error); ?>

							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<div class="form-group">
						<label for="inputEmail" class="col-lg-2 control-label">Title</label>
						<div class="col-lg-10">
							<input type="text" name="title" class="form-control" id="inputEmail" placeholder="Title" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label for="inputPassword" class="col-lg-2 control-label">Description</label>
						<div class="col-lg-10">
							<textarea name="description" class="form-control">
							</textarea>
						</div>
					</div>
					<div class="form-group">
						<div class="col-lg-10 col-lg-offset-2">
							<button type="submit" class="btn btn-primary">Submit</button>
							<a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Back</a>
						</div>
					</div>
				</fieldset>
			</form>
		</div><!-- /.col-md-6 -->
	</div><!-- /.row -->
</div><!-- /.container -->

<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /* C:\xampp\htdocs\laravelcrud\resources\views/inc/create.blade.php */ ?>