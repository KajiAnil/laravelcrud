<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
	<div class="row">
		<legend>Read Article</legend>
		<p class="lead"><?php echo e($articles->title); ?></p>
		<p class="lead"><?php echo e($articles->description); ?></p>
		<a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Back</a>
	</div><!-- /.row -->

</div><!-- /.container -->
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /* C:\xampp\htdocs\laravelcrud\resources\views/inc/read.blade.php */ ?>