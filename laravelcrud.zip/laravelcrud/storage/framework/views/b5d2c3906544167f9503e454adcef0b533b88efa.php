<footer id="footer" class="text text-center">
	<p>Copyright &copy 2019</p>
	
</footer>
</body>
</html>
<?php /* C:\xampp\htdocs\laravelcrud\resources\views/inc/footer.blade.php */ ?>