<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Article;

class CreatesController extends Controller
{
	//get the all data from the table named article 
	public function home(){
		$articles = Article::all();
		return view('home', ['articles' => $articles]);
	}

	//add the all data from the form to the table named article 
	public function add(Request $request){
		$this->validate($request,[
			'title' => 'required',
			'description' => 'required',
		]);

		$articles = new Article;
		$articles->title = $request->input('title');
		$articles->description = $request->input('description');
		$articles->save();
		return redirect('/')->with('info', 'Article Saved Successfully!');
	}

	public function update($id){
		$articles = Article::find($id);
		return view('inc.update', ['articles' => $articles]);

	}

	public function edit(Request $request, $id){
		$this->validate($request,[
			'title' => 'required',
			'description' => 'required',
		]);
		$data =  array(
			'title' => $request->input('title'),
			'description' => $request->input('description')
		);
		Article::where('id', $id)->update($data);
		return redirect('/')->with('info', 'Article Updated Successfully!');

	}

	public function read($id){
		$articles = Article::find($id);
		return view('inc.read', ['articles' => $articles]);
	}


	public function delete(Request $request, $id){
		Article::where('id', $id)->delete();
		return redirect('/')->with('info', 'Article Deleted Successfully!');

	}
}
