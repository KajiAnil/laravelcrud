<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('home');
// });

// Route for the home function on creates controller
Route::get('/', 'CreatesController@home');

// Route for the Create page
Route::get('/create', function () {
    return view('inc.create');
});

// Route for the add function on create controller
Route::post('/insert', 'CreatesController@add');

// Route for the add function on create controller
Route::get('/update/{id}', 'CreatesController@update');

// Route for the update function on create controller
Route::post('/edit/{id}', 'CreatesController@edit');


// Route for the read function on create controller
Route::get('/read/{id}', 'CreatesController@read');

// Route for the delete function on create controller
Route::get('/delete/{id}', 'CreatesController@delete');
